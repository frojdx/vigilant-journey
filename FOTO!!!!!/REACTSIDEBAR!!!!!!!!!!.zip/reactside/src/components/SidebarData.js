import React from 'react';
import * as FaIcons from 'react-icons/fa';
import * as AiIcons from 'react-icons/ai';
import * as IoIcons from 'react-icons/io';
import * as RiIcons from 'react-icons/ri';

export const SidebarData = [
  {
    title: 'Users',
    path: '/overview',
    icon: <AiIcons.AiFillHome />,
    iconClosed: <RiIcons.RiArrowDownSFill />,
    iconOpened: <RiIcons.RiArrowUpSFill />,

    subNav: [
      {
        title: 'Clients',
        path: '/overview/users',
        icon: <IoIcons.IoIosPaper />
      },
      {
        title: 'Admins',
        path: '/overview/revenue',
        icon: <IoIcons.IoIosPaper />
      },
      {
        title: 'SuperAdmins',
        path: '/overview/revenue',
        icon: <IoIcons.IoIosPaper />
      },
      {
        title: 'Advertisers',
        path: '/overview/revenue',
        icon: <IoIcons.IoIosPaper />
      },
      {
        title: 'Chatters',
        path: '/overview/revenue',
        icon: <IoIcons.IoIosPaper />
      },
      {
        title: 'Profiles',
        path: '/overview/revenue',
        icon: <IoIcons.IoIosPaper />
      }
    ]
  },
  {
    title: 'Gifts',
    path: '/reports',
    icon: <IoIcons.IoIosPaper />,
    iconClosed: <RiIcons.RiArrowDownSFill />,
    iconOpened: <RiIcons.RiArrowUpSFill />,


    subNav: [
      {
        title: 'Coin Pricing',
        path: '/reports/reports1',
        icon: <IoIcons.IoIosPaper />,
        cName: 'sub-nav'
      },
      {
        title: 'Mass Spams',
        path: '/reports/reports2',
        icon: <IoIcons.IoIosPaper />,
        cName: 'sub-nav'
      },
      {
        title: 'Coupons',
        path: '/reports/reports3',
        icon: <IoIcons.IoIosPaper />
      }
    ]
  },
  {
    title: 'Coin Pricing',
    path: '/products',
    icon: <FaIcons.FaCartPlus />
  },
  {
    title: 'Mass Spams',
    path: '/products',
    icon: <FaIcons.FaCartPlus />
  },
  {
    title: 'Coupons',
    path: '/products',
    icon: <FaIcons.FaCartPlus />
  },
  {
    title: 'Waiting Room',
    path: '/products',
    icon: <FaIcons.FaCartPlus />
  },
  {
    title: 'Active Dialogues',
    path: '/team',
    icon: <IoIcons.IoMdPeople />
  },
  {
    title: 'Payments',
    path: '/messages',
    icon: <FaIcons.FaEnvelopeOpenText/>
  },
  {
    title: 'Logins',
    path: '/support',
    icon: <IoIcons.IoMdHelpCircle />
  }
];
